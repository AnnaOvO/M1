package exo3;

import APIRequest.Answer;
import APIRequest.Request;
import exo2.Fastest;

import java.util.Optional;
import java.util.concurrent.ArrayBlockingQueue;

public class CheapestPooled {
  private final String item;
  private final int timeoutMilliPerRequest;

  public CheapestPooled(String item, int timeoutMilliPerRequest) {
    this.item = item;
    this.timeoutMilliPerRequest = timeoutMilliPerRequest;
  }
  /**
   * @return the fastest price for item if it is sold
   */
  public Optional<Answer> retrieve() throws InterruptedException {
    var sites = Request.ALL_SITES;
    var queue = new ArrayBlockingQueue<Answer>(sites.size());
    var threads = Request.ALL_SITES.stream()
        .map(site -> Thread.ofPlatform().start(() -> {
          Answer answer = null;
          try {
            answer = new Request(site, item).request(timeoutMilliPerRequest);
            queue.put(answer);
          } catch (InterruptedException e) {
            return;
          }
        }))
        .toList();
    for (var i = 0; i < sites.size(); i++){
      var answer = queue.take();
      if (answer.isSuccessful()){
        for (var thread : threads){
          thread.interrupt();
        }
        return Optional.of(answer);
      }
    }
    return Optional.empty();
  }

  public static void main(String[] args) throws InterruptedException {
    var agregator = new Fastest("tortank", 2_000);
    var answer = agregator.retrieve();
    System.out.println(answer); // Optional[tortank@... : ...]
  }
}
